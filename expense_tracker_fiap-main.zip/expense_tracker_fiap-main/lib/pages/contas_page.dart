import 'package:flutter/material.dart';

class ContasPage extends StatefulWidget {
  const ContasPage({super.key});

  @override
  State<ContasPage> createState() => _ContasPageState();
}

class _ContasPageState extends State<ContasPage> {
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Contas Page'),
    );
  }
}

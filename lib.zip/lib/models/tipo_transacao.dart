enum TipoTransacao{
  receita,
  despesa,
}